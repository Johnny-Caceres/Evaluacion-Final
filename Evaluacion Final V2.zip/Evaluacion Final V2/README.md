# Subir archivo excel usando PHP, MySQL, JQuery Ajax

![Image of screenshot](https://github.com/DesarrolloWebyTutoriales/subir-archivo-excel-jquery-ajax/blob/master/images/screenshot.jpg)

Pasos para ejecutar el aplicativo

1. Descargar el aplicativo.

2. Descomprimir el archivo zipeado. Copiar y pegar el aplicativo a un servidor local (PC) o subirlo a un hosting

3. Subir el archivo sql datos.sql al phpMyAdmin.

4. Modificar el archivo "conexion.php" de la carpeta includes:

```php
define("SERVIDOR","nombre del servidor"); // nombre del servidor (por defecto es localhost)
define("USUARIO","usuario"); // El usuario de la base de datos MySQL
define("CLAVE","tu clave"); // La clave de la bd MySQL. Si tienes instado xampp, dejarlo en blanco
define("BASE_DATOS","tu base de datos"); //El nombre de la base de datos que has creado.
```

5. Ejecutar la aplicación y listo.

¡Suscribete a mi canal!

https://www.youtube.com/playlist?list=PLcNBm08RlSWkiDX00X2OoHympH47FT4_T
