<?php 

	$conexion=mysqli_connect('localhost','root','','agenda');

 ?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css" />
	<title>mostrar datos</title>
</head>
<body class="b1">

<br>

	<table id="tb1" >
	
	
		<tr>
	  <th><label>ID</label><br/></th>
	  <th><label>Nombres</label><br/></th>
	  <th><label>Apellidos</label><br/></th>
	  <th><label>Direccion</label><br/></th>
      <th><label>Celular</label><br/></th>
      <th><label>Email</label><br/></th>	
		</tr>
		
		<?php 
		$sql="SELECT * from datos";
		$result=mysqli_query($conexion,$sql);

		while($mostrar=mysqli_fetch_array($result)){
		 ?>

		<tr>
			<td><?php echo $mostrar['id'] ?></td>
			<td><?php echo $mostrar['nombres'] ?></td>
			<td><?php echo $mostrar['apellidos'] ?></td>
			<td><?php echo $mostrar['direccion'] ?></td>
      		<td><?php echo $mostrar['celular'] ?></td>
      		<td><?php echo $mostrar['email'] ?></td>
		</tr>
	<?php 
	}
	
	 ?>
	 <?php
      $conexion=mysqli_connect('localhost','root','','agenda');

      $id    ="";
	  $nombres ="";
	  $apellidos="";
      $direcciones    ="";
	  $celular    ="";
	  $emai="";

      if(isset($_POST['btn_registrar']))
      {      
        echo "Presiono el boton Registrar";
      }

      if(isset($_POST['btn_consultar']))
      {
        echo "Presiono el boton consultar";
      }

      if(isset($_POST['btn_actualizar']))
      {
        echo "Presiono el boton actualizar";
      }

      if(isset($_POST['btn_eliminar']))
      {
        echo "Presiono el boton eliminar";
      }

  ?>
	</table>

</body>
</html>